package dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.DbConnection;
import dao.UserlistDao;
import model.Customer;
import model.Userlist;

public class UserlistDaoImpl implements UserlistDao {
	public static void main(String[] args) {
		
		//new UserlistDaoImpl().add(new Userlist("aa","789"));
	}

	@Override
	public void add(Userlist u) {
		Connection conn=DbConnection.getDb();
		String SQL="insert into Userlist(username,password)"
				+" values(?,?)";
		try {
			PreparedStatement ps=conn.prepareStatement(SQL);
			ps.setString(1,u.getUsername());
			ps.setString(2,u.getPassword());
			ps.executeUpdate();
			System.out.println("新增成功");
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		
	}

	@Override
	public List<Userlist> selectUserlist(String username,String password) {
		Connection conn=DbConnection.getDb();
		String sql = "SELECT * FROM userlist WHERE username = ? AND password = ?";

		List<Userlist> l=new ArrayList();
       try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2,password);
			
			
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				Userlist u=new Userlist();
				u.setUsername(rs.getString("username"));
				u.setPassword(rs.getString("password"));
				
				
				l.add(u);
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return l;
	}
		
	

	@Override
	public List<Userlist> quertByName(String username) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Userlist> selectAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Userlist> selectByUsername(String username) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Userlist u) {
		// TODO Auto-generated method stub
		
	}

}
