package dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.CustomerDao;
import dao.DbConnection;
import model.Customer;

public class CustomerDaoImpl implements CustomerDao {

	public static void main(String[] args) {
		new CustomerDaoImpl().deleteCustomer(0);

	}

	@Override
	public void add(Customer c) {
		Connection conn=DbConnection.getDb();
		String SQL="insert into Customer(name,service,date,phone)"
				+" values(?,?,?,?)";
		try {
			PreparedStatement ps=conn.prepareStatement(SQL);
			ps.setString(1,c.getName());
			ps.setString(2,c.getService());
			ps.setString(3,c.getDate());
			ps.setString(4,c.getPhone());
			
			ps.executeUpdate();
			System.out.println("新增成功");
		}catch(SQLException e){
			e.printStackTrace();
		}
	}

	@Override
	public List<Customer> selectAll() {
		Connection conn=DbConnection.getDb();
		String SQL="select*from customer";
		List<Customer> l=new ArrayList();
		try {
			PreparedStatement ps=conn.prepareStatement(SQL);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Customer c=new Customer();
				c.setId(rs.getInt("id"));
				c.setName(rs.getString("name"));
				c.setService(rs.getString("service"));
				c.setDate(rs.getString("date"));
				c.setPhone(rs.getString("phone"));
				l.add(c);
			}
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		return l;
		
	}

	@Override
	public List<Customer> quertByName(String name) {
		Connection conn=DbConnection.getDb();
		String SQL="SELECT*FROM customer WHERE name=?";
		List<Customer> l=new ArrayList();
		try {
			PreparedStatement ps=conn.prepareStatement(SQL);
			ps.setString(1, name);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {Customer c=new Customer();
			c.setId(rs.getInt("id"));
			c.setName(rs.getString("name"));
			c.setService(rs.getString("service"));
			c.setDate(rs.getString("date"));
			c.setPhone(rs.getString("phone"));
			l.add(c);
				
			}
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		return l;
		
	}

	@Override
	public void deleteCustomer(int id) {
		Connection conn=DbConnection.getDb();
		String SQL="delete from customer where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(SQL);
			ps.setInt(1, id);
			ps.executeUpdate();
		
		}catch(SQLException e){
			e.printStackTrace();
		}
		
	}

	


}
