package dao;

import java.util.List;

import model.Customer;

public interface CustomerDao {
	
	//create
	void add(Customer c);
	
	//read
	List<Customer> selectAll();
	List<Customer> quertByName(String name);
	
	
	void deleteCustomer(int id);
	

}
