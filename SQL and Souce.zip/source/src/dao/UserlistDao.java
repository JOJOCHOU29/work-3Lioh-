package dao;

import java.util.List;

import model.Userlist;

public interface UserlistDao {
	//create
		void add(Userlist u);
		
	//read
		List<Userlist> selectAll();
		List<Userlist> quertByName(String username);

		List<Userlist> selectUserlist(String username, String password);
	//update
		void update(Userlist u);
		
		
		

}
