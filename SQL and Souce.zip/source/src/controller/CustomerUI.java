package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Component;

import javax.swing.border.TitledBorder;

import com.toedter.calendar.JDateChooser;

import model.Customer;
import service.Impl.CustomerServiceImpl;

import javax.swing.border.EtchedBorder;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.border.LineBorder;
import javax.swing.JTextField;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class CustomerUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField name1;
	private JTextField date1;
	protected Component frame;
	private static CustomerServiceImpl csi=new CustomerServiceImpl ();
	private JTextField phone1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerUI frame = new CustomerUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustomerUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 251, 217));
		contentPane.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "3Lioh \u7167\u76F8\u9928 ", TitledBorder.LEFT, TitledBorder.TOP, null, new Color(128, 128, 128)));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("預約表單");
		lblNewLabel.setFont(new Font("微軟正黑體", Font.BOLD, 24));
		lblNewLabel.setBounds(171, 10, 198, 41);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(192, 192, 192), 6));
		panel.setBackground(new Color(255, 251, 217));
		panel.setBounds(26, 78, 431, 360);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("預約名字");
		lblNewLabel_1.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		lblNewLabel_1.setBounds(10, 52, 95, 31);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("預約服務");
		lblNewLabel_2.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		lblNewLabel_2.setBounds(10, 113, 95, 31);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("預約日期");
		lblNewLabel_3.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		lblNewLabel_3.setBounds(10, 181, 95, 31);
		panel.add(lblNewLabel_3);
		
		name1 = new JTextField();
		name1.setBounds(115, 52, 246, 31);
		panel.add(name1);
		name1.setColumns(10);
		
		JComboBox service1 = new JComboBox();
		service1.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		service1.addItem("請選擇");
		service1.addItem("基本證件照");
		service1.addItem("證件照+基礎彩妝");
		service1.addItem("拍攝+精緻妝髮");
		service1.addItem("精美沙龍照");
		
		service1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String service=(String)service1.getSelectedItem();
				switch(service){
				case"請選擇":
					System.out.println("尚未選擇");
					break;
				case"基本證件照":
					System.out.println("基本證件照");
					break;
				case"證件照+基礎彩妝":
					System.out.println("證件照+基礎彩妝");
					break;
				case"拍攝+精緻妝髮":
					System.out.println("拍攝+精緻妝髮");
					break;					
				case"精美沙龍照":
					System.out.println("精美沙龍照");
					break;					
				}
			}
		});
		
		
		
		service1.setBounds(115, 114, 246, 31);
		panel.add(service1);
		
		date1 = new JTextField();
		date1.setBounds(115, 181, 160, 35);
		panel.add(date1);
		date1.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("新增預約");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String Name=name1.getText();
				String Service=service1.getSelectedItem().toString();
				String Date=date1.getText();
				String Phone=phone1.getText();
				csi.addCustomer(new Customer(Name,Service,Date,Phone));
				
				JOptionPane.showMessageDialog(CustomerUI.this, "預約完成!", "預約完成!", JOptionPane.WARNING_MESSAGE);
				JOptionPane.showMessageDialog(CustomerUI.this, "已發送預約簡訊!", "已發送預約簡訊!", JOptionPane.WARNING_MESSAGE);
			}
		});
		btnNewButton_1.setFont(new Font("微軟正黑體", Font.BOLD, 18));
		btnNewButton_1.setBackground(Color.LIGHT_GRAY);
		btnNewButton_1.setBounds(272, 319, 136, 31);
		panel.add(btnNewButton_1);
		
		JButton showDateButton = new JButton("查詢日期");
		showDateButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				test t=new test();
				t.setVisible(true);
				dispose();
			}
		});
		showDateButton.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		showDateButton.setBounds(285, 182, 101, 31);
		panel.add(showDateButton);
		
		JLabel lblNewLabel_4 = new JLabel("(日期格式e.g.:2024.5.13)");
		lblNewLabel_4.setForeground(SystemColor.windowBorder);
		lblNewLabel_4.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		lblNewLabel_4.setBounds(10, 222, 255, 28);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("手機號碼");
		lblNewLabel_5.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		lblNewLabel_5.setBounds(10, 265, 84, 31);
		panel.add(lblNewLabel_5);
		
		phone1 = new JTextField();
		phone1.setBounds(115, 260, 246, 35);
		panel.add(phone1);
		phone1.setColumns(10);
		
		
	}
}
