package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.JTable;

public class PageUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PageUI frame = new PageUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PageUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 240));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(192, 192, 192), 7));
		panel.setBackground(new Color(255, 255, 240));
		panel.setBounds(10, 10, 666, 92);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("☆*:.｡. o3Lioh照相館o .｡.:*☆\r\n");
		lblNewLabel.setFont(new Font("宋体", Font.BOLD, 30));
		lblNewLabel.setBounds(59, 10, 573, 72);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(192, 192, 192), 5));
		panel_1.setBackground(new Color(255, 255, 240));
		panel_1.setBounds(10, 126, 560, 327);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("<html>3Lioh 照相館是一家致力於提供高品質影像服務的專業照相館。<br>無論是珍貴的家庭照片、個人肖像，還是企業活動，我們都提供一流的攝影服務和個性化的拍攝體驗。<br>自成立以來，我們一直秉承著「捕捉每一刻的美好」的理念，為客戶創造珍貴的回憶。<br>在 3Lioh 照相館，我們相信每一張照片都有其獨特的價值。<br>我們的團隊由經驗豐富的攝影師組成，他們不僅具備技術上的專業能力，更對每一個拍攝瞬間充滿熱情。<br>我們致力於為每一位客戶提供量身定制的服務，以確保每一個拍攝項目都能超出您的期待。<br>我們位於台北，歡迎隨時來店洽詢或預約拍攝服務。您也可以通過 [電話] 或 [線上預約] 與我們聯繫。我們期待為您提供最優質的攝影服務，捕捉您生活中的每一個珍貴瞬間。</html>");
		lblNewLabel_1.setFont(new Font("宋体", Font.BOLD, 16));
		lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_1.setBounds(10, 10, 534, 307);
		panel_1.add(lblNewLabel_1);
		
		JButton btnNewButton_1 = new JButton("服務項目簡介");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddServiceUI a=new AddServiceUI();
				a.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(365, 262, 141, 40);
		panel_1.add(btnNewButton_1);
		btnNewButton_1.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		
		JButton btnNewButton = new JButton("登入預約");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Welecome a=new Welecome();
				a.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		btnNewButton.setBounds(580, 417, 96, 23);
		contentPane.add(btnNewButton);
	}
}
