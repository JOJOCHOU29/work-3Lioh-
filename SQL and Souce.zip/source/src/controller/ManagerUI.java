package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ManagerUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField user;
	private JTextField pass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManagerUI frame = new ManagerUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManagerUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 550, 400);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 251, 217));
		contentPane.setBorder(new TitledBorder(null, "3Lioh\u7167\u76F8\u9928", TitledBorder.LEADING, TitledBorder.TOP, null, Color.LIGHT_GRAY));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(Color.LIGHT_GRAY, 5));
		panel.setBackground(new Color(255, 251, 217));
		panel.setBounds(10, 28, 516, 56);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("***系統後臺管理***");
		lblNewLabel.setFont(new Font("宋体", Font.BOLD, 30));
		lblNewLabel.setBounds(88, 10, 283, 36);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("管理者帳號");
		lblNewLabel_1.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		lblNewLabel_1.setBounds(10, 146, 95, 29);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("密碼");
		lblNewLabel_2.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		lblNewLabel_2.setBounds(54, 207, 51, 34);
		contentPane.add(lblNewLabel_2);
		
		user = new JTextField();
		user.setBounds(105, 152, 208, 34);
		contentPane.add(user);
		user.setColumns(10);
		
		pass = new JTextField();
		pass.setBounds(105, 203, 208, 29);
		contentPane.add(pass);
		pass.setColumns(10);
		
		JButton btnNewButton = new JButton("登入後臺");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Username=user.getText();
				String Password=pass.getText();
				if(Username.contains("manager")&&Password.contains("12345")) {
					user.setText("");
					pass.setText("");
					AddManagerUI a=new AddManagerUI();
					a.setVisible(true);
					
				}
				else {
					System.out.println("something Wrong...");
				}
			}
		});
		btnNewButton.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		btnNewButton.setBounds(374, 303, 110, 23);
		contentPane.add(btnNewButton);
	}

}
