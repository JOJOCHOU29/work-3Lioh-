package controller;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JDateChooser;
import java.awt.Color;
import java.awt.Font;

public class test extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					test frame = new test();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public test() {
		
		
		SwingUtilities.invokeLater(() -> {
            // Create the frame
            JFrame frame = new JFrame("Date Picker Example");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(400, 200);
            frame.getContentPane().setLayout(new BorderLayout());

            // Create a panel to hold the date picker
            JPanel panel = new JPanel();
            panel.setBackground(new Color(255, 251, 217));
            panel.setLayout(null);

            // Create a JDateChooser
            JDateChooser dateChooser = new JDateChooser();
            dateChooser.setBounds(61, 9, 92, 21);
            dateChooser.setDateFormatString("yyyy-MM-dd"); // Set the date format

            // Add the date chooser to the panel
            panel.add(dateChooser);

            // Add the panel to the frame
            frame.getContentPane().add(panel, BorderLayout.CENTER);

            // Add a button to show the selected date
            JButton showDateButton = new JButton("Show Selected Date");
            showDateButton.setBounds(158, 5, 167, 29);
            showDateButton.setFont(new Font("微軟正黑體", Font.BOLD, 14));
            panel.add(showDateButton);
            
            JButton btnNewButton = new JButton("返回");
            btnNewButton.addActionListener(new ActionListener() {
            	public void actionPerformed(ActionEvent e) {
            		CustomerUI a=new CustomerUI();
					a.setVisible(true);
					dispose();
            	}
            });
            btnNewButton.setFont(new Font("微軟正黑體", Font.BOLD, 14));
            btnNewButton.setBounds(276, 130, 85, 23);
            panel.add(btnNewButton);

            // Action listener for the button
            showDateButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    java.util.Date selectedDate = dateChooser.getDate();
                    if (selectedDate != null) {
                        JOptionPane.showMessageDialog(frame, "Selected Date: " + selectedDate);
                    } else {
                        JOptionPane.showMessageDialog(frame, "No Date Selected");
                    }
                }
            });

            // Display the frame
            frame.setVisible(true);
        });
	}

}
