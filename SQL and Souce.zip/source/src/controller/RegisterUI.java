package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.DbConnection;
import dao.Impl.UserlistDaoImpl;
import model.Userlist;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.SystemColor;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;

public class RegisterUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel register1;
	private JTextField username1;
	private JTextField password1;
	private JButton register2;
	private JButton btnNewButton;
	private JLabel lblNewLabel_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegisterUI frame = new RegisterUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegisterUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 550, 400);
		register1 = new JPanel();
		register1.setBackground(new Color(255, 251, 217));
		register1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "3Lioh\u7167\u76F8\u9928", TitledBorder.LEADING, TitledBorder.TOP, null, Color.GRAY));

		setContentPane(register1);
		register1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("請輸入帳號");
		lblNewLabel.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		lblNewLabel.setBounds(32, 100, 99, 31);
		register1.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("請輸入密碼");
		lblNewLabel_1.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		lblNewLabel_1.setBounds(32, 209, 99, 41);
		register1.add(lblNewLabel_1);
		
		username1 = new JTextField();
		username1.setBounds(141, 100, 196, 31);
		register1.add(username1);
		username1.setColumns(10);
		
		password1 = new JTextField();
		password1.setBounds(141, 209, 196, 31);
		register1.add(password1);
		password1.setColumns(10);
		
		register2 = new JButton("註冊");
		register2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Username = username1.getText();
			    String Password = password1.getText();
			    
			    new UserlistDaoImpl().add(new Userlist(Username, Password));
			    JOptionPane.showMessageDialog(RegisterUI.this, "註冊成功!", "註冊成功!", JOptionPane.WARNING_MESSAGE);
			    
					}
				
						
				 
				
			
		});
		register2.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		register2.setBounds(228, 330, 85, 23);
		register1.add(register2);
		
		btnNewButton = new JButton("返回登入頁");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginUI a=new LoginUI();
				a.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		btnNewButton.setBounds(348, 330, 131, 23);
		register1.add(btnNewButton);
		
		lblNewLabel_2 = new JLabel("(帳號密碼創建設定在20個字元內哦*^o^*例：\r\n帳號：李小姐\r\n密碼：899）");
		lblNewLabel_2.setForeground(SystemColor.textInactiveText);
		lblNewLabel_2.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		lblNewLabel_2.setIcon(null);
		lblNewLabel_2.setBounds(32, 263, 494, 31);
		register1.add(lblNewLabel_2);
		
		
		
	
			}}
		