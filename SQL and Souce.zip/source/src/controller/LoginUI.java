package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;

public class LoginUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField username;
	private JTextField password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginUI frame = new LoginUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 550, 400);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 251, 217));
		contentPane.setBorder(new TitledBorder(null, "3Lioh\u7167\u76F8\u9928", TitledBorder.LEADING, TitledBorder.TOP, null, Color.GRAY));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("帳號");
		lblNewLabel.setFont(new Font("微軟正黑體", Font.BOLD, 18));
		lblNewLabel.setBounds(20, 115, 84, 35);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("密碼");
		lblNewLabel_1.setFont(new Font("微軟正黑體", Font.BOLD, 18));
		lblNewLabel_1.setBounds(20, 210, 70, 27);
		contentPane.add(lblNewLabel_1);
		
		username = new JTextField();
		username.setBounds(114, 120, 222, 35);
		contentPane.add(username);
		username.setColumns(10);
		
		password = new JTextField();
		password.setBounds(114, 200, 222, 37);
		contentPane.add(password);
		password.setColumns(10);
		
		JButton login = new JButton("登入!");
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Username = username.getText();
			    String Password = password.getText();
			
			model.Userlist u=new service.Impl.UserlistServiceImpl().Login(Username, Password);
			    
					if (u!=null) {
				      JOptionPane.showMessageDialog(LoginUI.this, "登入成功", "登入成功", JOptionPane.WARNING_MESSAGE);
				      CustomerUI a=new CustomerUI();
						a.setVisible(true);
						dispose();
				 
					}
					else {
					       JOptionPane.showMessageDialog(LoginUI.this, "帳號不存在", "登入失敗", JOptionPane.ERROR_MESSAGE);
					      } 

			}
		});
		login.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		login.setBounds(368, 252, 85, 23);
		contentPane.add(login);
		
		JButton register = new JButton("還未有帳號?註冊");
		register.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegisterUI a=new RegisterUI();
				a.setVisible(true);
				dispose();
				
			}
		});
		register.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		register.setBounds(324, 311, 154, 23);
		contentPane.add(register);
		
		JButton btnNewButton = new JButton("返回首頁");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PageUI a=new PageUI();
				a.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		btnNewButton.setBounds(147, 311, 117, 23);
		contentPane.add(btnNewButton);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(Color.LIGHT_GRAY, 5));
		panel.setBackground(new Color(255, 251, 217));
		panel.setBounds(10, 22, 516, 60);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("☆*:.｡. o3Lioh照相館o .｡.:*☆");
		lblNewLabel_2.setFont(new Font("宋体", Font.BOLD, 28));
		lblNewLabel_2.setBounds(10, 10, 496, 40);
		panel.add(lblNewLabel_2);
	}

}
