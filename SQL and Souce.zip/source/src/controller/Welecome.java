package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.awt.event.ActionEvent;

public class Welecome extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Welecome frame = new Welecome();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Welecome() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 550, 400);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 240));
		contentPane.setBorder(new TitledBorder(null, "\u2606*:.\uFF61. o(\u2267\u25BD\u2266)o .\uFF61.:*\u2606\u2606*:.\uFF61. o(\u2267\u25BD\u2266)o .\uFF61.:*\u2606\u2606*:.\uFF61. o(\u2267\u25BD\u2266)o .\uFF61.:*\u2606\u2606*:.\uFF61. o(\u2267\u25BD\u2266)o .\uFF61.:*\u2606", TitledBorder.LEADING, TitledBorder.TOP, null, Color.LIGHT_GRAY));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(192, 192, 192), 5));
		panel.setBackground(new Color(255, 255, 240));
		panel.setBounds(10, 23, 516, 52);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("☆*:.｡. o3Lioh照相館o .｡.:*☆");
		lblNewLabel.setFont(new Font("宋体", Font.BOLD, 30));
		lblNewLabel.setBounds(10, 10, 496, 32);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Welecome!");
		lblNewLabel_1.setFont(new Font("宋体", Font.BOLD, 40));
		lblNewLabel_1.setBounds(152, 85, 215, 45);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(Welecome.class.getResource("/controller/非會員1.png")));
		lblNewLabel_2.setBounds(23, 140, 150, 147);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(Welecome.class.getResource("/controller/會員1.png")));
		lblNewLabel_3.setBounds(196, 140, 155, 147);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon(Welecome.class.getResource("/controller/管理者1.png")));
		lblNewLabel_4.setBounds(361, 140, 150, 152);
		contentPane.add(lblNewLabel_4);
		
		JButton btnNewButton = new JButton("非會員");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegisterUI a=new RegisterUI();
				a.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton.setFont(new Font("宋体", Font.BOLD, 14));
		btnNewButton.setBounds(33, 297, 110, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("會員");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginUI a=new LoginUI();
				a.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton_1.setFont(new Font("宋体", Font.BOLD, 14));
		btnNewButton_1.setBounds(206, 297, 120, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("管理者");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManagerUI a=new ManagerUI();
				a.setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("宋体", Font.BOLD, 14));
		btnNewButton_2.setBounds(381, 302, 102, 23);
		contentPane.add(btnNewButton_2);
		
	    }

	}

