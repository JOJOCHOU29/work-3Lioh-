package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.border.LineBorder;

import model.Customer;
import service.Impl.CustomerServiceImpl;

import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.ScrollPane;
import javax.swing.event.AncestorListener;
import javax.swing.event.AncestorEvent;
import javax.swing.JScrollPane;

public class AddManagerUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField name4;
	private JTextField service4;
	private JTextField date4;
	private JTextField phone4;
	private static CustomerServiceImpl csi=new CustomerServiceImpl ();
	private JTextField id4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddManagerUI frame = new AddManagerUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddManagerUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 251, 217));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(Color.LIGHT_GRAY, 3));
		panel.setBackground(new Color(255, 251, 217));
		panel.setBounds(10, 10, 616, 141);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("預約姓名");
		lblNewLabel.setFont(new Font("微軟正黑體", Font.BOLD, 13));
		lblNewLabel.setBounds(10, 10, 79, 30);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("預約服務");
		lblNewLabel_1.setFont(new Font("微軟正黑體", Font.BOLD, 13));
		lblNewLabel_1.setBounds(10, 63, 79, 36);
		panel.add(lblNewLabel_1);
		
		name4 = new JTextField();
		name4.setBounds(70, 15, 180, 25);
		panel.add(name4);
		name4.setColumns(10);
		
		service4 = new JTextField();
		service4.setBounds(70, 71, 180, 28);
		panel.add(service4);
		service4.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("預約日期");
		lblNewLabel_2.setFont(new Font("微軟正黑體", Font.BOLD, 13));
		lblNewLabel_2.setBounds(295, 10, 79, 30);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("手機號碼");
		lblNewLabel_3.setFont(new Font("微軟正黑體", Font.BOLD, 13));
		lblNewLabel_3.setBounds(295, 76, 67, 23);
		panel.add(lblNewLabel_3);
		
		date4 = new JTextField();
		date4.setBounds(371, 17, 208, 30);
		panel.add(date4);
		date4.setColumns(10);
		
		phone4 = new JTextField();
		phone4.setBounds(368, 63, 211, 36);
		panel.add(phone4);
		phone4.setColumns(10);
		
		JButton btnNewButton = new JButton("新增");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Name=name4.getText();
				String Service=service4.getText();
				String Date=date4.getText();
				String Phone=phone4.getText();
				
				csi.addCustomer(new Customer(Name,Service,Date,Phone));	
				
			}
		});
		btnNewButton.setBounds(521, 107, 85, 23);
		panel.add(btnNewButton);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(Color.LIGHT_GRAY, 3));
		panel_1.setBackground(new Color(255, 251, 217));
		panel_1.setBounds(10, 161, 616, 288);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JTextArea output = new JTextArea();
		output.setLineWrap(true);
		output.setBounds(10, 10, 596, 235);
		panel_1.add(output);
		
		JButton btnNewButton_1 = new JButton("查詢");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				List<Customer> l=csi.findAll();
				String show="";
				
				for(Customer c:l)
				{
					show=show+"預約姓名:"+c.getName()+"\t預約服務:"+c.getService()+"\t預約日期:"+c.getDate()+"\t手機號碼:"+c.getPhone()+"\n";
				}
				output.setText(show);
			}
		});
		btnNewButton_1.setBounds(521, 255, 85, 23);
		panel_1.add(btnNewButton_1);
		
		JButton btnNewButton_3 = new JButton("列印訂單資訊");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
              try {
					
					output.print();
				}catch(PrinterException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_3.setBounds(393, 255, 119, 23);
		panel_1.add(btnNewButton_3);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(Color.LIGHT_GRAY, 3));
		panel_2.setBackground(new Color(255, 251, 217));
		
		
		panel_2.setBounds(10, 459, 616, 94);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("Id (刪除訂單)");
		lblNewLabel_4.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		lblNewLabel_4.setBounds(10, 10, 119, 42);
		panel_2.add(lblNewLabel_4);
		
		id4 = new JTextField();
		id4.setBounds(112, 44, 54, 40);
		panel_2.add(id4);
		id4.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("刪除");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ID=Integer.parseInt(id4.getText());
				csi.deleteCustomer(ID);
			}
		});
		btnNewButton_2.setBounds(521, 61, 85, 23);
		panel_2.add(btnNewButton_2);
	}
}
