package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;

public class AddServiceUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddServiceUI frame = new AddServiceUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddServiceUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1200, 1000);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 251, 217));
		contentPane.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "3Lioh\u7167\u76F8\u9928", TitledBorder.LEADING, TitledBorder.TOP, null, Color.GRAY));

		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton("返回首頁");
		btnNewButton.setBounds(1062, 106, 114, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PageUI a=new PageUI();
				a.setVisible(true);
				dispose();
			}
		});
		contentPane.setLayout(null);
		btnNewButton.setFont(new Font("宋体", Font.BOLD, 16));
		contentPane.add(btnNewButton);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 139, 457, 234);
		panel.setBorder(new LineBorder(Color.LIGHT_GRAY, 2));
		panel.setBackground(new Color(255, 251, 217));
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(10, 10, 182, 192);
		panel.add(lblNewLabel_2);
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_2.setIcon(new ImageIcon(AddServiceUI.class.getResource("/controller/基本證件照1.png")));
		
		JLabel lblNewLabel_4 = new JLabel("<html>【基本證件照500元】<br>證件照拍攝<br>客製化修圖、一對一線上照片校稿<br>實體照片輸出：1吋或2吋證件照8張</html>");
		lblNewLabel_4.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_4.setBounds(203, 10, 244, 192);
		panel.add(lblNewLabel_4);
		lblNewLabel_4.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 417, 457, 251);
		panel_1.setBorder(new LineBorder(Color.LIGHT_GRAY, 2));
		panel_1.setBackground(new Color(255, 251, 217));
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(10, 22, 180, 180);
		panel_1.add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon(AddServiceUI.class.getResource("/controller/基礎彩妝2.png")));
		
		JLabel lblNewLabel_8 = new JLabel("<html>【證件照+基礎彩妝800元】<br>基礎彩妝 (畫眉/基本底妝/唇色/不包含眼妝設計) <br>證件照拍攝<br>客製化修圖、一對一線上照片校稿<br>實體照片輸出：1吋或2吋證件照8張 or 美國簽證2張 (可加價加洗不同尺寸)</html>");
		lblNewLabel_8.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_8.setBounds(200, 22, 247, 219);
		panel_1.add(lblNewLabel_8);
		lblNewLabel_8.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(520, 139, 544, 234);
		panel_2.setBorder(new LineBorder(Color.LIGHT_GRAY, 2));
		panel_2.setBackground(new Color(255, 251, 217));
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(10, 10, 182, 192);
		panel_2.add(lblNewLabel_1);
		lblNewLabel_1.setIcon(new ImageIcon(AddServiceUI.class.getResource("/controller/精緻彩妝3.png")));
		
		JLabel lblNewLabel_13 = new JLabel("<html>【拍攝+精緻妝髮1300元】<br>精緻彩妝(眼妝設計, 底妝, 客製化調整眉型, 修容輪廓, 五官立體妝)<br>髮型整理, 以及電棒設計簡單造型<br>證件照拍攝<br>客製化修圖、一對一線上照片校稿<br>實體照片輸出：1吋或2吋證件照8張 or 美國簽證2張 (可加價加洗不同尺寸)<br>Email照片指定尺寸電子檔一張</html>");
		lblNewLabel_13.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_13.setBounds(202, 10, 321, 214);
		panel_2.add(lblNewLabel_13);
		lblNewLabel_13.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(520, 417, 570, 251);
		panel_3.setBorder(new LineBorder(Color.LIGHT_GRAY, 2));
		panel_3.setBackground(new Color(255, 251, 217));
		contentPane.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(10, 10, 245, 234);
		panel_3.add(lblNewLabel_3);
		lblNewLabel_3.setIcon(new ImageIcon(AddServiceUI.class.getResource("/controller/沙龍照41.png")));
		
		JLabel lblNewLabel_18 = new JLabel("<html>【精美沙龍照2600元】\r\n<br>服務內容：\r\n<br>精緻彩妝服務：\r\n<br>• 底妝：無瑕底妝、遮瑕、立體修容、腮紅\r\n<br>• 眉型：修眉及客製化眉型設計\r\n<br>• 眼妝：眼影暈染、眼線、睫毛膏、臥蠶\r\n<br>• 髮型：髮型吹整、電棒造型、綁髮等\r\n<br>Email發送精修電子檔案一張<br> 實體照片輸出：4*6一張</html>");
		lblNewLabel_18.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_18.setBounds(245, 10, 315, 234);
		panel_3.add(lblNewLabel_18);
		lblNewLabel_18.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(10, 23, 1048, 106);
		panel_4.setBorder(new LineBorder(Color.LIGHT_GRAY, 5));
		panel_4.setBackground(new Color(255, 251, 217));
		contentPane.add(panel_4);
		panel_4.setLayout(null);
		
		JLabel lblNewLabel_5 = new JLabel("☆*:.｡. o3Lioh照相館 服務項目o .｡.:*☆\r\n");
		lblNewLabel_5.setFont(new Font("宋体", Font.BOLD, 44));
		lblNewLabel_5.setBounds(36, 10, 1002, 86);
		panel_4.add(lblNewLabel_5);
	}

}
