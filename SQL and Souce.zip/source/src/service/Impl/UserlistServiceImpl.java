package service.Impl;

import java.util.List;

import dao.Impl.UserlistDaoImpl;
import model.Userlist;
import service.UserlistService;

public class UserlistServiceImpl implements UserlistService{

	public static void main(String[] args) {
		System.out.println(new UserlistServiceImpl().findByUsername("abcrrrr") );

	}
	private static UserlistDaoImpl udi=new UserlistDaoImpl();
	
	
	
	
	@Override
	public Userlist Login(String username, String password) {
		List< Userlist> l=udi.selectUserlist(username, password);	
		Userlist u=null;
		if(l.size()!=0)
		{
			u=l.get(0);
		}
		
		return u;
	}
	
	
	@Override
	public boolean findByUsername(String username) {
		List< Userlist> l=udi.selectByUsername(username);
		boolean x=false;
		if(l.size()!=0)
		{
			x=true;
		}
		
		return x;
	}

	


	@Override
	public void addUserlist(Userlist u) {
		udi.add(u);
	}

}
