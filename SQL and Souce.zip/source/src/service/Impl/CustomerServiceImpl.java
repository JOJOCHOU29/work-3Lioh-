package service.Impl;

import java.util.List;

import dao.Impl.CustomerDaoImpl;
import model.Customer;
import service.CustomerService;

public class CustomerServiceImpl implements CustomerService {
	public static void main(String[]args) {
		
	}
	private static CustomerDaoImpl cdi=new CustomerDaoImpl();

	@Override
	public void addCustomer(Customer c) {
		cdi.add(c);
		
	}

	@Override
	public List<Customer> findAll() {
		
		return cdi.selectAll();
	}

	

	@Override
	public void deleteCustomer(int id) {
		cdi.deleteCustomer(id);
		
	}

	@Override
	public void updateCustomer(int id, String name, String service, String date, String phone) {
		List<Customer> l=cdi.selectAll();
		Customer c=l.get(0);
		c.setName(name);
		c.setService(service);
		c.setDate(date);
		c.setPhone(phone);
		
		
		
	
		
		
		
		
	}

	
		
	

}
