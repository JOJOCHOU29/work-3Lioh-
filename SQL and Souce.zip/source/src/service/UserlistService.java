package service;

import model.Userlist;

public interface UserlistService {
	Userlist Login(String username,String password);//登入
	boolean findByUsername(String username);
	void addUserlist(Userlist u);

}
