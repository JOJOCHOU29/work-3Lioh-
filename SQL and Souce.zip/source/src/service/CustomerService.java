package service;

import java.util.List;

import model.Customer;

public interface CustomerService {
	void addCustomer(Customer c);
	
	
	List<Customer>findAll();
	
	void updateCustomer(int id,String name,String service,String date,String phone);
	void deleteCustomer(int id);
	
	
	

}
